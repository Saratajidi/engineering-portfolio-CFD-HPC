"""Airfoil geometry: NACA 4-digit sections and Joukowski sections with their exact solution."""
import numpy as np


def naca4(code="0012", n_panels=200, closed_te=True):
    """Nodes of a NACA 4-digit section, ordered TE -> lower surface -> LE -> upper surface -> TE.

    Cosine spacing; unit chord. Returns arrays x, y of length n_panels + 1.
    """
    m, p, t = int(code[0]) / 100.0, int(code[1]) / 10.0, int(code[2:]) / 100.0
    beta = np.linspace(0.0, np.pi, n_panels // 2 + 1)
    xc = 0.5 * (1.0 - np.cos(beta))                       # 0 (LE) -> 1 (TE)
    a4 = -0.1036 if closed_te else -0.1015
    yt = 5 * t * (0.2969 * np.sqrt(xc) - 0.1260 * xc - 0.3516 * xc**2 + 0.2843 * xc**3 + a4 * xc**4)
    if m > 0:
        yc = np.where(xc < p, m / p**2 * (2 * p * xc - xc**2),
                      m / (1 - p)**2 * ((1 - 2 * p) + 2 * p * xc - xc**2))
        dyc = np.where(xc < p, 2 * m / p**2 * (p - xc), 2 * m / (1 - p)**2 * (p - xc))
    else:
        yc, dyc = np.zeros_like(xc), np.zeros_like(xc)
    th = np.arctan(dyc)
    xu, yu = xc - yt * np.sin(th), yc + yt * np.cos(th)
    xl, yl = xc + yt * np.sin(th), yc - yt * np.cos(th)
    x = np.concatenate([xl[::-1], xu[1:]])
    y = np.concatenate([yl[::-1], yu[1:]])
    return x, y


class Joukowski:
    """Joukowski section z = zeta + 1/zeta from a circle centred at mu = -eps + i*delta."""

    def __init__(self, eps=0.0925, delta=0.0):
        self.mu = complex(-eps, delta)
        self.a = abs(1.0 - self.mu)
        self.beta = np.arcsin(delta / self.a)
        th = np.linspace(0, 2 * np.pi, 20001)
        z = self._z(self.mu + self.a * np.exp(1j * th))
        self.x_le, self.chord = z.real.min(), z.real.max() - z.real.min()

    @staticmethod
    def _z(zeta):
        return zeta + 1.0 / zeta

    def nodes(self, n_panels):
        """Panel nodes, TE -> lower -> LE -> upper -> TE, scaled to unit chord with LE at x = 0."""
        th = -self.beta - np.linspace(0.0, 2 * np.pi, n_panels + 1)
        z = self._z(self.mu + self.a * np.exp(1j * th))
        z[0] = z[-1] = 2.0                                 # exact cusp
        return (z.real - self.x_le) / self.chord, z.imag / self.chord

    def exact(self, alpha_deg, n=2001):
        """Exact surface x/c, y/c, Cp and the exact lift coefficient."""
        al = np.radians(alpha_deg)
        th = -self.beta - np.linspace(0.0, 2 * np.pi, n)[1:-1]
        zeta = self.mu + self.a * np.exp(1j * th)
        gam = 4 * np.pi * self.a * np.sin(al + self.beta)
        w = (np.exp(-1j * al) - self.a**2 * np.exp(1j * al) / (zeta - self.mu)**2
             + 1j * gam / (2 * np.pi * (zeta - self.mu))) / (1.0 - 1.0 / zeta**2)
        z = self._z(zeta)
        cl = 8 * np.pi * self.a * np.sin(al + self.beta) / self.chord
        return (z.real - self.x_le) / self.chord, z.imag / self.chord, 1 - np.abs(w)**2, cl


class KarmanTrefftz(Joukowski):
    """Karman-Trefftz section: like Joukowski but with a finite trailing-edge angle tau (degrees)."""

    def __init__(self, eps=0.08, delta=0.0, tau_deg=10.0):
        self.k = 2.0 - np.radians(tau_deg) / np.pi
        super().__init__(eps, delta)

    def _w(self, zeta):
        return ((zeta - 1.0) / (zeta + 1.0)) ** self.k

    def _z(self, zeta):
        w = self._w(zeta)
        return self.k * (1 + w) / (1 - w)

    def nodes(self, n_panels):
        th = -self.beta - np.linspace(0.0, 2 * np.pi, n_panels + 1)
        z = self._z(self.mu + self.a * np.exp(1j * th))
        z[0] = z[-1] = self.k
        return (z.real - self.x_le) / self.chord, z.imag / self.chord

    def exact(self, alpha_deg, n=2001):
        al = np.radians(alpha_deg)
        th = -self.beta - np.linspace(0.0, 2 * np.pi, n)[1:-1]
        zeta = self.mu + self.a * np.exp(1j * th)
        gam = 4 * np.pi * self.a * np.sin(al + self.beta)
        w = self._w(zeta)
        dz = 4 * self.k**2 * w / ((zeta**2 - 1.0) * (1 - w)**2)
        vel = (np.exp(-1j * al) - self.a**2 * np.exp(1j * al) / (zeta - self.mu)**2
               + 1j * gam / (2 * np.pi * (zeta - self.mu))) / dz
        z = self._z(zeta)
        cl = 8 * np.pi * self.a * np.sin(al + self.beta) / self.chord
        return (z.real - self.x_le) / self.chord, z.imag / self.chord, 1 - np.abs(vel)**2, cl
