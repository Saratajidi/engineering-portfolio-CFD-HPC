"""One-dimensional compressible Euler equations: finite volume, HLLC flux, optional MUSCL
reconstruction with a slope limiter, SSP Runge-Kutta 2. Includes the exact Riemann solution."""
import numpy as np

G = 1.4


def prim_to_cons(w):
    rho, u, p = w
    return np.array([rho, rho * u, p / (G - 1) + 0.5 * rho * u**2])


def cons_to_prim(q):
    rho = q[0]; u = q[1] / rho
    return np.array([rho, u, (G - 1) * (q[2] - 0.5 * rho * u**2)])


def hllc(wl, wr):
    rl, ul, pl = wl; rr, ur, pr = wr
    al, ar = np.sqrt(G * pl / rl), np.sqrt(G * pr / rr)
    sl, sr = np.minimum(ul - al, ur - ar), np.maximum(ul + al, ur + ar)
    sm = (pr - pl + rl * ul * (sl - ul) - rr * ur * (sr - ur)) / (rl * (sl - ul) - rr * (sr - ur))
    ql, qr = prim_to_cons(wl), prim_to_cons(wr)
    fl = np.array([ql[1], ql[1] * ul + pl, ul * (ql[2] + pl)])
    fr = np.array([qr[1], qr[1] * ur + pr, ur * (qr[2] + pr)])

    def star(q, w, s):
        r, u, p = w
        f = r * (s - u) / (s - sm)
        return np.array([f, f * sm, f * (q[2] / r + (sm - u) * (sm + p / (r * (s - u))))])

    fsl, fsr = fl + sl * (star(ql, wl, sl) - ql), fr + sr * (star(qr, wr, sr) - qr)
    return np.where(sl >= 0, fl, np.where(sm >= 0, fsl, np.where(sr > 0, fsr, fr)))


def limiter(a, b, kind):
    if kind == "minmod":
        return np.where(a * b > 0, np.where(np.abs(a) < np.abs(b), a, b), 0.0)
    if kind == "vanleer":
        return np.where(a * b > 0, 2 * a * b / (a + b + 1e-300), 0.0)
    if kind == "none":                                     # unlimited central slope
        return 0.5 * (a + b)
    raise ValueError(kind)


def rhs(q, dx, order, lim, periodic):
    w = cons_to_prim(q)
    pad = (lambda v: np.concatenate([v[:, -2:], v, v[:, :2]], axis=1)) if periodic else \
          (lambda v: np.concatenate([v[:, :1], v[:, :1], v, v[:, -1:], v[:, -1:]], axis=1))
    wg = pad(w)
    if order == 1:
        wl, wr = wg[:, 1:-2], wg[:, 2:-1]
    else:
        d = np.diff(wg, axis=1)
        s = limiter(d[:, :-1], d[:, 1:], lim)              # slopes for cells 1 .. n+2 of wg
        wl, wr = (wg[:, 1:-1] + 0.5 * s)[:, :-1], (wg[:, 1:-1] - 0.5 * s)[:, 1:]
    f = hllc(wl, wr)
    return -(f[:, 1:] - f[:, :-1]) / dx


def run(w0, x, t_end, order=2, lim="vanleer", cfl=0.4, periodic=False):
    q, dx, t = prim_to_cons(w0), x[1] - x[0], 0.0
    while t < t_end - 1e-14:
        w = cons_to_prim(q)
        dt = min(cfl * dx / (np.abs(w[1]) + np.sqrt(G * w[2] / w[0])).max(), t_end - t)
        if order == 1:
            q = q + dt * rhs(q, dx, 1, lim, periodic)
        else:
            q1 = q + dt * rhs(q, dx, 2, lim, periodic)
            q = 0.5 * (q + q1 + dt * rhs(q1, dx, 2, lim, periodic))
        t += dt
    return cons_to_prim(q)


def exact_riemann(wl, wr, xi):
    """Exact solution at similarity coordinates xi = (x - x0) / t (Toro, ch. 4)."""
    rl, ul, pl = wl; rr, ur, pr = wr
    al, ar = np.sqrt(G * pl / rl), np.sqrt(G * pr / rr)

    def fk(p, rk, pk, ak):
        if p > pk:
            A, B = 2 / ((G + 1) * rk), (G - 1) / (G + 1) * pk
            return (p - pk) * np.sqrt(A / (p + B)), np.sqrt(A / (p + B)) * (1 - (p - pk) / (2 * (B + p)))
        return 2 * ak / (G - 1) * ((p / pk) ** ((G - 1) / (2 * G)) - 1), (p / pk) ** (-(G + 1) / (2 * G)) / (rk * ak)

    p = 0.5 * (pl + pr)
    for _ in range(100):
        f1, d1 = fk(p, rl, pl, al); f2, d2 = fk(p, rr, pr, ar)
        dp = (f1 + f2 + ur - ul) / (d1 + d2)
        p = max(p - dp, 1e-12)
        if abs(dp) < 1e-14 * p:
            break
    u = 0.5 * (ul + ur) + 0.5 * (fk(p, rr, pr, ar)[0] - fk(p, rl, pl, al)[0])
    out = np.empty((3, len(xi)))
    gm = (G - 1) / (G + 1)
    for i, s in enumerate(xi):
        if s <= u:                                          # left of the contact
            if p > pl:
                sl = ul - al * np.sqrt((G + 1) / (2 * G) * p / pl + (G - 1) / (2 * G))
                out[:, i] = (rl, ul, pl) if s < sl else (rl * (p / pl + gm) / (gm * p / pl + 1), u, p)
            else:
                ast = al * (p / pl) ** ((G - 1) / (2 * G))
                if s < ul - al:
                    out[:, i] = (rl, ul, pl)
                elif s > u - ast:
                    out[:, i] = (rl * (p / pl) ** (1 / G), u, p)
                else:
                    c = 2 / (G + 1) + gm * (ul - s) / al
                    out[:, i] = (rl * c ** (2 / (G - 1)), 2 / (G + 1) * (al + (G - 1) / 2 * ul + s), pl * c ** (2 * G / (G - 1)))
        else:
            if p > pr:
                sr = ur + ar * np.sqrt((G + 1) / (2 * G) * p / pr + (G - 1) / (2 * G))
                out[:, i] = (rr, ur, pr) if s > sr else (rr * (p / pr + gm) / (gm * p / pr + 1), u, p)
            else:
                ast = ar * (p / pr) ** ((G - 1) / (2 * G))
                if s > ur + ar:
                    out[:, i] = (rr, ur, pr)
                elif s < u + ast:
                    out[:, i] = (rr * (p / pr) ** (1 / G), u, p)
                else:
                    c = 2 / (G + 1) - gm * (ur - s) / ar
                    out[:, i] = (rr * c ** (2 / (G - 1)), 2 / (G + 1) * (-ar + (G - 1) / 2 * ur + s), pr * c ** (2 * G / (G - 1)))
    return out, p, u


def sod(n, order=2, lim="vanleer", t_end=0.2):
    x = (np.arange(n) + 0.5) / n
    w0 = np.where(x < 0.5, np.array([[1.0], [0.0], [1.0]]), np.array([[0.125], [0.0], [0.1]]))
    w = run(w0, x, t_end, order, lim)
    ex, ps, us = exact_riemann((1.0, 0.0, 1.0), (0.125, 0.0, 0.1), (x - 0.5) / t_end)
    return x, w, ex, np.abs(w[0] - ex[0]).mean()


def smooth_wave(n, order=2, lim="vanleer", t_end=1.0):
    """Density wave advected once around a periodic domain: the exact answer is the initial state."""
    x = (np.arange(n) + 0.5) / n
    w0 = np.array([1.0 + 0.2 * np.sin(2 * np.pi * x), np.ones(n), np.ones(n)])
    w = run(w0, x, t_end, order, lim, periodic=True)
    return x, w, w0, np.abs(w[0] - w0[0]).mean()
