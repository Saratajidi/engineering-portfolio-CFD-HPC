# Aerodynamics studies

Code behind the eight studies in the portfolio. Python 3 with NumPy, SciPy, Numba, threadpoolctl and Matplotlib.
Studies 6-8 measure the machine they run on; their numbers change from one computer to another.

    python make_figures.py

reruns every study, writes the figures to ../figs and all quoted numbers to ../figs/results.json.

| File | Contents |
|---|---|
| airfoil.py | NACA 4-digit sections; Joukowski and Karman-Trefftz sections with their exact pressure and lift |
| panel.py | Hess-Smith panel method (sources + one vortex strength, Kutta condition), surface and field velocity |
| ibl.py | Thwaites laminar method, Michel transition, Head turbulent method, Squire-Young drag |
| llt.py | Lifting-line theory, Glauert series |
| bemt.py | Propeller blade-element momentum theory with tip/hub loss and a power audit |
| euler1d.py | 1D Euler finite-volume solver (HLLC, MUSCL, SSP-RK2) and exact Riemann solver |
| poisson.py | Jacobi, red-black Gauss-Seidel, SOR, CG and geometric multigrid for the 2D Poisson equation |
| roofline.py | Peak-FLOP and STREAM measurements, three versions of a Jacobi stencil (NumPy, fused Numba, blocked) |
| decomp.py | Strip domain decomposition with halo exchange over pipes, ping-pong benchmark, cost model |
| make_figures.py | Runs the studies and produces figures and results (`python make_figures.py study_decomp` reruns one) |

Reference values used for comparison: NASA Turbulence Modeling Resource, 2D NACA 0012 validation case
(Spalart-Allmaras, CFL3D): CL = 1.0909 and CD = 0.01231 at 10 deg, CD = 0.00819 at 0 deg; Re = 6e6, M = 0.15.
