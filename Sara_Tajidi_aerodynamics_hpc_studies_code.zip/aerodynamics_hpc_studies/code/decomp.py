"""Domain decomposition of an explicit 2D stencil solver with message-passing halo exchange.

Each rank owns a horizontal strip of the grid plus one halo row above and below. Every time step
the ranks exchange halo rows with their neighbours over pipes (the same pattern as MPI_Sendrecv),
then update their interior. Timings separate computation from communication so that a cost model
can be fitted and used where the machine has fewer cores than one would like.
"""
import time
import multiprocessing as mp
import numpy as np
from numba import njit


@njit(fastmath=True, cache=True)
def step(u, out, c):
    n, m = u.shape
    for i in range(1, n - 1):
        for j in range(1, m - 1):
            out[i, j] = u[i, j] + c * (u[i - 1, j] + u[i + 1, j] + u[i, j - 1] + u[i, j + 1] - 4.0 * u[i, j])


def worker(rank, size, n, steps, up, down, result):
    rows = n // size + (1 if rank < n % size else 0)
    u = np.zeros((rows + 2, n + 2)); out = np.zeros_like(u)
    u[1:-1, 1:-1] = np.random.rand(rows, n)
    step(u, out, 0.2)                                        # compile before timing
    t_comm = t_comp = 0.0
    t0 = time.perf_counter()
    for _ in range(steps):
        t = time.perf_counter()
        if up is not None:                                   # exchange with the rank above
            up.send(u[1].copy())
        if down is not None:                                 # and the rank below
            down.send(u[-2].copy())
        if up is not None:
            u[0] = up.recv()
        if down is not None:
            u[-1] = down.recv()
        t_comm += time.perf_counter() - t
        t = time.perf_counter()
        step(u, out, 0.2)
        u, out = out, u
        t_comp += time.perf_counter() - t
    result.put((rank, time.perf_counter() - t0, t_comm, t_comp, rows))


def run(n, size, steps=50):
    """Wall time per step of the whole job, and the mean communication and computation shares."""
    ctx = mp.get_context("fork")
    result = ctx.Queue()
    pipes = [ctx.Pipe() for _ in range(size - 1)]            # pipe k links rank k (down) and k+1 (up)
    procs = []
    for r in range(size):
        up = pipes[r - 1][1] if r > 0 else None
        down = pipes[r][0] if r < size - 1 else None
        procs.append(ctx.Process(target=worker, args=(r, size, n, steps, up, down, result)))
    for p in procs:
        p.start()
    out = [result.get() for _ in procs]
    for p in procs:
        p.join()
    wall = max(o[1] for o in out) / steps
    comm = np.mean([o[2] for o in out]) / steps
    comp = np.mean([o[3] for o in out]) / steps
    return dict(n=n, size=size, wall=wall, comm=comm, comp=comp, cells_per_rank=n * n / size)


def best_of(n, size, steps=50, repeats=3):
    runs = [run(n, size, steps) for _ in range(repeats)]
    return min(runs, key=lambda r: r["wall"])


def _pong(conn, sizes, reps):
    for s in sizes:
        for _ in range(reps):
            conn.send(conn.recv())


def pingpong(sizes=(8, 64, 512, 4096, 32768, 262144, 2097152, 8388608), reps=200):
    """Round-trip message cost over a pipe against message size: latency and bandwidth (bytes/s)."""
    ctx = mp.get_context("fork")
    a, b = ctx.Pipe()
    p = ctx.Process(target=_pong, args=(b, sizes, reps)); p.start()
    out = []
    for s in sizes:
        msg = np.zeros(s // 8)
        a.send(msg); a.recv()                                # warm up
        t = time.perf_counter()
        for _ in range(reps - 1):
            a.send(msg); a.recv()
        out.append((s, (time.perf_counter() - t) / (reps - 1) / 2))   # one-way time
    p.join()
    sizes_b = np.array([o[0] for o in out], float); times = np.array([o[1] for o in out])
    small = sizes_b <= 4096
    latency = times[small].mean()                             # flat part of the curve
    bandwidth = (sizes_b[-1] - sizes_b[-2]) / (times[-1] - times[-2])   # slope of the large-message end
    return dict(sizes=sizes_b, times=times, latency=latency, bandwidth=bandwidth)


def compute_rate(n=2048, steps=100):
    """Cells updated per second by one rank with no communication."""
    r = run(n, 1, steps)
    return n * n / r["comp"]


def model_efficiency(cells_per_rank, p, rate, latency, bandwidth, n_halo=2):
    """Efficiency of a strip decomposition: E = t1 / (p * tp), halo rows exchanged each step."""
    n = np.sqrt(cells_per_rank * p)                           # square global grid
    t_comp = cells_per_rank / rate
    t_comm = n_halo * (latency + 8.0 * n / bandwidth)
    return t_comp / (t_comp + t_comm)


if __name__ == "__main__":
    pp = pingpong(); print(f"latency {pp['latency']*1e6:.1f} us, bandwidth {pp['bandwidth']/1e9:.2f} GB/s")
    for n in (128, 256, 512, 1024, 2048, 4096):
        r1, r2 = best_of(n, 1), best_of(n, 2)
        print(n, f"p=1 {r1['wall']*1e3:.3f} ms  p=2 {r2['wall']*1e3:.3f} ms  comm {r2['comm']*1e3:.3f} ms  "
                 f"eff {r1['wall']/(2*r2['wall']):.3f}  cells/rank {r2['cells_per_rank']:.0f}")


