"""Blade-element momentum theory for a propeller in axial flight, with Prandtl tip and hub loss."""
import numpy as np
from scipy.optimize import brentq


def section(alpha, cl_alpha=5.9, alpha0=np.radians(-2.0), cl_max=1.3, cd0=0.010, k=0.012):
    """Simple section model: linear lift with a smooth stall, parabolic polar, flat-plate post-stall."""
    cl_lin = cl_alpha * (alpha - alpha0)
    cl = cl_max * np.tanh(cl_lin / cl_max)
    stalled = 0.5 * (1 + np.tanh((np.abs(cl_lin) - cl_max) / 0.15))
    cd = cd0 + k * cl**2 + stalled * 1.2 * np.sin(alpha - alpha0) ** 2
    return cl, cd


class Propeller:
    def __init__(self, blades=2, pitch_ratio=0.8, hub=0.15, n_el=40, solidity_scale=1.0):
        self.B, self.hub = blades, hub
        xe = np.linspace(hub, 1.0, n_el + 1)
        self.x = 0.5 * (xe[:-1] + xe[1:])                 # r / R at element centres
        self.dx = np.diff(xe)
        self.c = solidity_scale * 0.16 * np.sqrt(1 - ((self.x - 0.45) / 0.62) ** 2) * (1 - self.x**6) ** 0.5 + 0.02
        self.beta = np.arctan(pitch_ratio / (np.pi * self.x))   # constant geometric pitch

    def _loss(self, x, phi, tip_loss):
        if not tip_loss:
            return 1.0
        sp = max(abs(np.sin(phi)), 1e-6)
        ft = self.B / 2 * (1 - x) / (x * sp)
        fh = self.B / 2 * (x - self.hub) / (self.hub * sp)
        return max((2 / np.pi) ** 2 * np.arccos(np.exp(-ft)) * np.arccos(np.exp(-fh)), 1e-4)

    def run(self, J, tip_loss=True, drag=True):
        """Advance ratio J = V/(nD). Non-dimensional: R = 1, n = 1 rev/s, rho = 1.

        Each element is solved for its inflow angle phi with a bracketed root find on the
        momentum / blade-element residual (Ning, 2014), which avoids fixed-point divergence.
        """
        x, c, B = self.x, self.c, self.B
        V, om = 2.0 * J, 2 * np.pi                         # D = 2
        sigma = B * c / (2 * np.pi * x)
        n = len(x)
        a, ap, phi, cy, cx, cd = (np.zeros(n) for _ in range(6))
        ok = True
        for i in range(n):
            lam = V / (om * x[i])

            def parts(ph):
                cl_, cd_ = section(self.beta[i] - ph)
                cd_ = cd_ if drag else 0.0
                cy_ = cl_ * np.cos(ph) - cd_ * np.sin(ph)
                cx_ = cl_ * np.sin(ph) + cd_ * np.cos(ph)
                F = self._loss(x[i], ph, tip_loss)
                kap = sigma[i] * cy_ / (4 * F * np.sin(ph) ** 2)
                kapp = sigma[i] * cx_ / (4 * F * np.sin(ph) * np.cos(ph))
                return kap, kapp, cy_, cx_, cd_

            def resid(ph):
                kap, kapp, *_ = parts(ph)
                return np.sin(ph) * (1 - kap) - lam * np.cos(ph) * (1 + kapp)

            lo, hi = 1e-6, np.pi / 2 - 1e-6
            if resid(lo) * resid(hi) > 0:
                ok = False
                continue
            phi[i] = brentq(resid, lo, hi, xtol=1e-13, rtol=1e-13)
            kap, kapp, cy[i], cx[i], cd[i] = parts(phi[i])
            a[i], ap[i] = kap / (1 - kap), kapp / (1 + kapp)
        W2 = (V * (1 + a)) ** 2 + (om * x * (1 - ap)) ** 2
        dT = 0.5 * W2 * B * c * cy * self.dx
        dQ = 0.5 * W2 * B * c * cx * x * self.dx
        T, Q = dT.sum(), dQ.sum()
        P = om * Q
        CT, CP = T / 16.0, P / 32.0                        # rho n^2 D^4 = 16, rho n^3 D^5 = 32
        # independent power audit: shaft = useful + axial induced + swirl + profile drag
        profile = (0.5 * W2**1.5 * B * c * cd * self.dx).sum()
        useful = T * V
        axial = (dT * V * a).sum()
        swirl = (om * ap * dQ).sum()
        Tc = T / (0.5 * V**2 * np.pi) if V > 0 else np.inf
        eta_ideal = 2.0 / (1.0 + np.sqrt(1.0 + Tc)) if V > 0 else 0.0
        return dict(J=J, CT=CT, CP=CP, eta=useful / P if P > 0 else 0.0, eta_ideal=eta_ideal,
                    useful=useful / P, profile=profile / P, axial=axial / P, swirl=swirl / P,
                    induced=(axial + swirl) / P, closure=abs(1 - (useful + axial + swirl + profile) / P),
                    converged=ok, a=a, ap=ap, phi=phi, alpha=self.beta - phi, dT=dT / self.dx)
