"""Iterative solvers for the 2D Poisson equation on the unit square (5-point stencil, Dirichlet).

Jacobi, red-black Gauss-Seidel, SOR, conjugate gradients and a geometric multigrid V-cycle,
all on the same discretisation, so that iteration counts and times are comparable.
"""
import time
import numpy as np
from numba import njit


def manufactured(n):
    """Grid of n x n interior points, exact solution sin(pi x) sin(pi y) and its right-hand side."""
    h = 1.0 / (n + 1)
    x = np.linspace(0.0, 1.0, n + 2)
    X, Y = np.meshgrid(x, x, indexing="ij")
    # two frequencies plus a polynomial: not an eigenfunction of the discrete operator
    u_exact = np.sin(np.pi * X) * np.sin(2 * np.pi * Y) + X * (1 - X) * Y * (1 - Y)
    f = -5.0 * np.pi**2 * np.sin(np.pi * X) * np.sin(2 * np.pi * Y) - 2.0 * (Y * (1 - Y) + X * (1 - X))
    return h, u_exact, f


def residual(u, f, h):
    """r = f - Lu on interior points (u carries the boundary ring)."""
    r = np.zeros_like(u)
    r[1:-1, 1:-1] = f[1:-1, 1:-1] - (u[:-2, 1:-1] + u[2:, 1:-1] + u[1:-1, :-2] + u[1:-1, 2:]
                                     - 4.0 * u[1:-1, 1:-1]) / h**2
    return r


@njit(cache=True)
def jacobi_sweep(u, f, h, out):
    n, m = u.shape
    for i in range(1, n - 1):
        for j in range(1, m - 1):
            out[i, j] = 0.25 * (u[i - 1, j] + u[i + 1, j] + u[i, j - 1] + u[i, j + 1] - h * h * f[i, j])


@njit(cache=True)
def rb_gauss_seidel_sweep(u, f, h, omega=1.0):
    """One red-black Gauss-Seidel (omega = 1) or SOR sweep, in place."""
    n, m = u.shape
    for colour in (0, 1):
        for i in range(1, n - 1):
            for j in range(1 + (i + colour) % 2, m - 1, 2):
                new = 0.25 * (u[i - 1, j] + u[i + 1, j] + u[i, j - 1] + u[i, j + 1] - h * h * f[i, j])
                u[i, j] = (1.0 - omega) * u[i, j] + omega * new


def solve_stationary(n, kind, tol=1e-8, max_iter=200000):
    h, ue, f = manufactured(n)
    u = np.zeros_like(ue); out = np.zeros_like(ue)
    r0 = np.linalg.norm(residual(u, f, h))
    omega = 2.0 / (1.0 + np.sin(np.pi * h)) if kind == "sor" else 1.0
    t = time.perf_counter()
    for it in range(1, max_iter + 1):
        if kind == "jacobi":
            jacobi_sweep(u, f, h, out); u, out = out, u
        else:
            rb_gauss_seidel_sweep(u, f, h, omega)
        if it % 10 == 0 and np.linalg.norm(residual(u, f, h)) / r0 < tol:
            break
    return dict(iters=it, time=time.perf_counter() - t, err=np.abs(u - ue).max(), u=u)


def laplace_apply(v, h):
    """-Laplacian of v on interior points, zero boundary: the SPD operator for CG."""
    out = np.zeros_like(v)
    out[1:-1, 1:-1] = (4.0 * v[1:-1, 1:-1] - v[:-2, 1:-1] - v[2:, 1:-1] - v[1:-1, :-2] - v[1:-1, 2:]) / h**2
    return out


def solve_cg(n, tol=1e-8, max_iter=100000):
    h, ue, f = manufactured(n)
    b = -f.copy(); b[0, :] = b[-1, :] = b[:, 0] = b[:, -1] = 0.0
    u = np.zeros_like(ue)
    r = b - laplace_apply(u, h); p = r.copy(); rr = np.vdot(r, r); r0 = np.sqrt(rr)
    t = time.perf_counter()
    for it in range(1, max_iter + 1):
        Ap = laplace_apply(p, h)
        alpha = rr / np.vdot(p, Ap)
        u += alpha * p; r -= alpha * Ap
        rr_new = np.vdot(r, r)
        if np.sqrt(rr_new) / r0 < tol:
            break
        p = r + (rr_new / rr) * p; rr = rr_new
    return dict(iters=it, time=time.perf_counter() - t, err=np.abs(u - ue).max(), u=u)


# ------------------------------------------------------------------ geometric multigrid
def restrict(r):
    """Full weighting from a (2n+1)-interior grid to an n-interior grid (sizes 2^k - 1)."""
    c = r[1:-1:2, 1:-1:2]
    out = np.zeros(((r.shape[0] - 1) // 2 + 1, (r.shape[1] - 1) // 2 + 1))
    out[1:-1, 1:-1] = (4 * r[2:-1:2, 2:-1:2] + 2 * (r[1:-2:2, 2:-1:2] + r[3::2, 2:-1:2] + r[2:-1:2, 1:-2:2] + r[2:-1:2, 3::2])
                       + r[1:-2:2, 1:-2:2] + r[1:-2:2, 3::2] + r[3::2, 1:-2:2] + r[3::2, 3::2]) / 16.0
    return out


def prolong(e):
    """Bilinear interpolation to the next finer grid."""
    nf = 2 * e.shape[0] - 1
    out = np.zeros((nf, nf))
    out[::2, ::2] = e
    out[1::2, ::2] = 0.5 * (e[:-1, :] + e[1:, :])
    out[::2, 1::2] = 0.5 * (e[:, :-1] + e[:, 1:])
    out[1::2, 1::2] = 0.25 * (e[:-1, :-1] + e[1:, :-1] + e[:-1, 1:] + e[1:, 1:])
    return out


def vcycle(u, f, h, nu1=2, nu2=2):
    if u.shape[0] <= 5:                                     # coarsest: a few exact-enough sweeps
        for _ in range(20):
            rb_gauss_seidel_sweep(u, f, h)
        return u
    for _ in range(nu1):
        rb_gauss_seidel_sweep(u, f, h)
    r = restrict(residual(u, f, h))
    e = vcycle(np.zeros_like(r), r, 2 * h)
    u[1:-1, 1:-1] += prolong(e)[1:-1, 1:-1]
    for _ in range(nu2):
        rb_gauss_seidel_sweep(u, f, h)
    return u


def solve_multigrid(n, tol=1e-8, max_cycles=100):
    h, ue, f = manufactured(n)
    u = np.zeros_like(ue)
    r0 = np.linalg.norm(residual(u, f, h))
    hist = [1.0]
    t = time.perf_counter()
    for it in range(1, max_cycles + 1):
        vcycle(u, f, h)
        hist.append(np.linalg.norm(residual(u, f, h)) / r0)
        if hist[-1] < tol:
            break
    return dict(iters=it, time=time.perf_counter() - t, err=np.abs(u - ue).max(), u=u, hist=np.array(hist))
