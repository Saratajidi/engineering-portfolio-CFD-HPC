"""Roofline measurements on the machine running this code, and where a CFD stencil sits on it.

Peak floating-point rate from a large double-precision matrix product (OpenBLAS), memory bandwidth
from a STREAM-style triad, then three implementations of the same Jacobi stencil: NumPy slicing
(several passes with temporaries), a fused single-pass Numba kernel, and the fused kernel with
cache blocking in the slow index.
"""
import os, time
import numpy as np
import numba
from numba import njit, prange


def _best(fn, repeats=5):
    return min(fn() for _ in range(repeats))


def peak_flops(n=2048, threads=1):
    """GFLOP/s of a double matrix product on the given number of threads."""
    import threadpoolctl
    a = np.random.rand(n, n); b = np.random.rand(n, n)
    with threadpoolctl.threadpool_limits(limits=threads):
        a @ b                                                # warm up
        def run():
            t = time.perf_counter(); a @ b; return time.perf_counter() - t
        return 2.0 * n**3 / _best(run) / 1e9


def stream_triad(n=64_000_000, threads=1):
    """GB/s for a = b + s*c on arrays far larger than any cache (3 x 512 MB)."""
    numba.set_num_threads(threads)
    b = np.random.rand(n); c = np.random.rand(n); a = np.empty_like(b)
    _triad(a, b, c, 3.0)
    def run():
        t = time.perf_counter(); _triad(a, b, c, 3.0); return time.perf_counter() - t
    return 3.0 * 8 * n / _best(run) / 1e9


@njit(parallel=True, fastmath=True, cache=True)
def _triad(a, b, c, s):
    for i in prange(a.shape[0]):
        a[i] = b[i] + s * c[i]


# ---------------------------------------------------------------- three versions of one stencil
def jacobi_numpy(u, f, h2, out):
    out[1:-1, 1:-1] = 0.25 * (u[:-2, 1:-1] + u[2:, 1:-1] + u[1:-1, :-2] + u[1:-1, 2:] - h2 * f[1:-1, 1:-1])


@njit(parallel=True, fastmath=True, cache=True)
def jacobi_fused(u, f, h2, out):
    n, m = u.shape
    for i in prange(1, n - 1):
        for j in range(1, m - 1):
            out[i, j] = 0.25 * (u[i - 1, j] + u[i + 1, j] + u[i, j - 1] + u[i, j + 1] - h2 * f[i, j])


@njit(parallel=True, fastmath=True, cache=True)
def jacobi_blocked(u, f, h2, out, bj=512):
    n, m = u.shape
    nb = (m - 2 + bj - 1) // bj
    for ib in prange(1, n - 1):
        for jb in range(nb):
            j0, j1 = 1 + jb * bj, min(1 + (jb + 1) * bj, m - 1)
            for j in range(j0, j1):
                out[ib, j] = 0.25 * (u[ib - 1, j] + u[ib + 1, j] + u[ib, j - 1] + u[ib, j + 1] - h2 * f[ib, j])


def stencil_rates(n=4096, threads=1, sweeps=10):
    """Achieved GFLOP/s and effective GB/s for the three stencil versions on an n x n grid."""
    numba.set_num_threads(threads)
    u = np.random.rand(n, n); f = np.random.rand(n, n); out = np.zeros_like(u)
    flops = 6.0 * (n - 2) ** 2                              # 4 adds, 1 multiply-add, 1 multiply
    bytes_min = 8.0 * 3 * (n - 2) ** 2                      # u read, f read, out written, once each
    res = {}
    for name, fn in (("numpy", jacobi_numpy), ("fused", jacobi_fused), ("blocked", jacobi_blocked)):
        fn(u, f, 1e-4, out)
        def run():
            t = time.perf_counter()
            for _ in range(sweeps):
                fn(u, f, 1e-4, out)
            return (time.perf_counter() - t) / sweeps
        dt = _best(run, 3)
        res[name] = dict(time=dt, gflops=flops / dt / 1e9, gbs=bytes_min / dt / 1e9)
    res["intensity"] = flops / bytes_min                   # FLOP per byte of compulsory traffic
    return res


def numpy_traffic_factor():
    """How many array passes NumPy slicing makes for the stencil: 4 adds -> temporaries, etc."""
    # u[:-2]+u[2:] : read 2, write 1 | + u[:, :-2] : read 2, write 1 | + u[:, 2:] : read 2, write 1
    # h2*f : read 1, write 1 | (...) - (...) : read 2, write 1 | 0.25* : read 1, write 1 | assign: read 1, write 1
    reads, writes = 2 + 2 + 2 + 1 + 2 + 1 + 1, 1 + 1 + 1 + 1 + 1 + 1 + 1
    return (reads + writes) / 3.0


if __name__ == "__main__":
    print("threads available", numba.config.NUMBA_NUM_THREADS, os.cpu_count())
    for th in (1, 2):
        print("peak GFLOP/s", th, round(peak_flops(threads=th), 1))
        print("triad GB/s", th, round(stream_triad(threads=th), 2))
        r = stencil_rates(threads=th)
        print(th, {k: (v if k == "intensity" else {kk: round(vv, 3) for kk, vv in v.items()}) for k, v in r.items()})
    print("numpy traffic factor", numpy_traffic_factor())
