"""Hess-Smith panel method: constant-strength sources on each panel plus one vortex strength,
closed by the Kutta condition. Incompressible, inviscid, two-dimensional."""
import numpy as np


class PanelSolution:
    def __init__(self, x, y, alpha_deg):
        self.x, self.y = np.asarray(x, float), np.asarray(y, float)
        self.alpha = np.radians(alpha_deg)
        x, y, al = self.x, self.y, self.alpha
        self.n = n = len(x) - 1
        self.xm, self.ym = 0.5 * (x[:-1] + x[1:]), 0.5 * (y[:-1] + y[1:])
        dx, dy = np.diff(x), np.diff(y)
        self.length = np.hypot(dx, dy)
        self.theta = np.arctan2(dy, dx)
        self.chord = x.max() - x.min()

        lnr, beta = self._geometry(self.xm, self.ym, on_surface=True)
        dth = self.theta[:, None] - self.theta[None, :]
        s, c = np.sin(dth), np.cos(dth)
        An_src = (s * lnr + c * beta) / (2 * np.pi)          # normal velocity, unit sources
        An_vor = (c * lnr - s * beta) / (2 * np.pi)          # normal velocity, unit vortex sheet
        At_src = (s * beta - c * lnr) / (2 * np.pi)          # tangential velocity, unit sources
        At_vor = (s * lnr + c * beta) / (2 * np.pi)

        A = np.zeros((n + 1, n + 1))
        b = np.zeros(n + 1)
        A[:n, :n], A[:n, n] = An_src, An_vor.sum(axis=1)
        b[:n] = np.sin(self.theta - al)                      # no flow through the surface
        A[n, :n] = At_src[0] + At_src[-1]                    # Kutta: Vt(first) = -Vt(last)
        A[n, n] = At_vor[0].sum() + At_vor[-1].sum()
        b[n] = -(np.cos(self.theta[0] - al) + np.cos(self.theta[-1] - al))
        sol = np.linalg.solve(A, b)
        self.q, self.gamma = sol[:n], sol[n]
        self.vt = np.cos(self.theta - al) + At_src @ self.q + self.gamma * At_vor.sum(axis=1)
        self.cp = 1.0 - self.vt**2
        self.residual = np.abs(A @ sol - b).max()

        # lift two ways: circulation (Kutta-Joukowski) and surface-pressure integration
        self.cl_kj = 2.0 * self.gamma * self.length.sum() / self.chord
        nx, ny = -np.sin(self.theta), np.cos(self.theta)
        fx, fy = -(self.cp * nx * self.length).sum(), -(self.cp * ny * self.length).sum()
        self.cl_p = (fy * np.cos(al) - fx * np.sin(al)) / self.chord
        self.cd_p = (fx * np.cos(al) + fy * np.sin(al)) / self.chord   # zero in exact theory
        self.cm_qc = ((self.cp * self.length * ((self.xm - 0.25 * self.chord - x.min()) * ny
                                                 - self.ym * nx)).sum()) / self.chord**2

    def _geometry(self, xp, yp, on_surface=False):
        """ln(r2/r1) and subtended angle of every panel seen from points (xp, yp)."""
        x, y = self.x, self.y
        dx1, dy1 = xp[:, None] - x[None, :-1], yp[:, None] - y[None, :-1]
        dx2, dy2 = xp[:, None] - x[None, 1:], yp[:, None] - y[None, 1:]
        lnr = 0.5 * np.log((dx2**2 + dy2**2) / (dx1**2 + dy1**2))
        beta = np.arctan2(dy2 * dx1 - dx2 * dy1, dx2 * dx1 + dy2 * dy1)
        if on_surface:
            np.fill_diagonal(beta, np.pi)
        return lnr, beta

    def velocity(self, xp, yp):
        """Velocity (u, v) at field points, free stream of unit speed."""
        shape = np.shape(xp)
        xp, yp = np.ravel(xp).astype(float), np.ravel(yp).astype(float)
        lnr, beta = self._geometry(xp, yp)
        ct, st = np.cos(self.theta), np.sin(self.theta)
        u_xi = (-self.q * lnr + self.gamma * beta) / (2 * np.pi)       # along each panel
        u_eta = (self.q * beta + self.gamma * lnr) / (2 * np.pi)       # normal to each panel
        u = np.cos(self.alpha) + (u_xi * ct - u_eta * st).sum(axis=1)
        v = np.sin(self.alpha) + (u_xi * st + u_eta * ct).sum(axis=1)
        return u.reshape(shape), v.reshape(shape)


def solve(x, y, alpha_deg):
    return PanelSolution(x, y, alpha_deg)
