"""Prandtl lifting-line theory solved with Glauert's Fourier series (symmetric loading)."""
import numpy as np


def solve(aspect_ratio, chord_fn, alpha_deg=5.0, twist_fn=None, a0=2 * np.pi, n_terms=60):
    """chord_fn(eta) -> c / c_mean for eta = |2y/b| in [0, 1]; twist_fn(eta) -> degrees (washout < 0).

    Returns CL, CDi, span efficiency e, and the span loading c*cl/(c_mean*CL) at eta.
    """
    k = np.arange(1, 2 * n_terms, 2)                       # odd harmonics only
    th = (np.arange(1, n_terms + 1) - 0.5) * np.pi / (2 * n_terms)   # collocation on a half span
    eta = np.cos(th)
    c = chord_fn(eta) / aspect_ratio                       # chord / span (c_mean = b / AR)
    alpha = np.radians(alpha_deg + (twist_fn(eta) if twist_fn else 0.0))
    mu = a0 * c / 4.0
    M = np.sin(np.outer(th, k)) * (np.sin(th)[:, None] + mu[:, None] * k[None, :])
    A = np.linalg.solve(M, mu * np.sin(th) * alpha)
    CL = np.pi * aspect_ratio * A[0]
    CDi = np.pi * aspect_ratio * (k * A**2).sum()
    e = A[0] ** 2 / (k * A**2).sum()
    eta_o = np.linspace(0, 1, 201)
    gam = 4.0 * (A[None, :] * np.sin(np.outer(np.arccos(eta_o), k))).sum(axis=1)   # 2*Gamma/(U*b)
    load = gam * aspect_ratio / CL                         # c*cl / (c_mean*CL)
    return dict(CL=CL, CDi=CDi, e=e, eta=eta_o, load=load, A=A)


def tapered(lam):
    return lambda eta: 2.0 / (1.0 + lam) * (1.0 - (1.0 - lam) * eta)


def elliptic():
    return lambda eta: 4.0 / np.pi * np.sqrt(np.maximum(1.0 - eta**2, 0.0))
