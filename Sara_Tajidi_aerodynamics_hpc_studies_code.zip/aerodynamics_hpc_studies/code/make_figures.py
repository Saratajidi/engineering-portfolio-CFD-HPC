"""Runs every study and writes the figures (SVG / PNG) and results.json used by the portfolio."""
import json, math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.path import Path as MplPath

from airfoil import naca4, Joukowski, KarmanTrefftz
import panel, ibl, llt, bemt, euler1d, poisson, roofline, decomp

OUT = Path(__file__).resolve().parent.parent / "figs"
OUT.mkdir(exist_ok=True)
for f in (Path(__file__).resolve().parent.parent / "fonts" / "ttf").glob("*.ttf"):
    font_manager.fontManager.addfont(str(f))

INK, MUTE, GRID, AXIS = "#0E2238", "#51606F", "#E4E9EE", "#B9C3CD"
BLUE, ORANGE, AQUA, REF = "#2a78d6", "#eb6834", "#1baf7a", "#7B8794"
plt.rcParams.update({
    "font.family": ["IBM Plex Sans", "DejaVu Sans"], "font.size": 7.6, "svg.fonttype": "path",
    "axes.edgecolor": AXIS, "axes.linewidth": 0.7, "axes.labelcolor": MUTE, "axes.labelsize": 7.8,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "axes.axisbelow": True,
    "grid.color": GRID, "grid.linewidth": 0.6, "xtick.color": MUTE, "ytick.color": MUTE,
    "xtick.major.size": 0, "ytick.major.size": 0, "xtick.minor.size": 0, "ytick.minor.size": 0,
    "xtick.labelsize": 7.2, "ytick.labelsize": 7.2, "lines.linewidth": 1.5,
    "lines.solid_capstyle": "round", "lines.solid_joinstyle": "round", "legend.frameon": False,
    "legend.fontsize": 7.4, "legend.labelcolor": INK, "legend.handlelength": 1.5,
    "figure.facecolor": "none", "axes.facecolor": "none", "savefig.facecolor": "none",
})
W, H = 3.42, 3.30          # one figure panel, inches
R = {}                      # every number quoted in the portfolio comes from here


def fig():
    f, ax = plt.subplots(figsize=(W, H))
    f.subplots_adjust(left=0.135, right=0.965, top=0.945, bottom=0.12)
    return f, ax


def save(f, name):
    f.savefig(OUT / f"{name}.svg")
    plt.close(f)


def dot(ax, x, y, color, **kw):
    ax.plot(x, y, ls="none", marker="o", ms=5.6, mfc=color, mec="white", mew=1.3, **kw)


def order(err, n):
    return float(np.log(err[-2] / err[-1]) / np.log(n[-1] / n[-2]))


# ------------------------------------------------------------------ cover: streamlines
def cover():
    x, y = naca4("4412", 240)
    al = 8.0
    sol = panel.solve(x, y, al)
    ca, sa = math.cos(math.radians(-al)), math.sin(math.radians(-al))
    # work in a frame where the free stream is horizontal: rotate the section instead
    xr, yr = (x - 0.25) * ca - y * sa + 0.25, (x - 0.25) * sa + y * ca
    gx, gy = np.linspace(-1.35, 2.75, 760), np.linspace(-1.05, 1.25, 430)
    X, Y = np.meshgrid(gx, gy)
    Xb, Yb = (X - 0.25) * ca + Y * sa + 0.25, -(X - 0.25) * sa + Y * ca      # back to body frame
    U, V = np.empty_like(X), np.empty_like(X)
    for i in range(0, X.shape[0], 20):
        u, v = sol.velocity(Xb[i:i + 20], Yb[i:i + 20])
        U[i:i + 20], V[i:i + 20] = u * ca - v * sa, u * sa + v * ca
    inside = MplPath(np.c_[xr, yr]).contains_points(np.c_[X.ravel(), Y.ravel()]).reshape(X.shape)
    U, V = np.ma.array(U, mask=inside), np.ma.array(V, mask=inside)
    speed = np.sqrt(U**2 + V**2)
    f = plt.figure(figsize=(11.693, 6.56), facecolor="none")
    ax = f.add_axes([0, 0, 1, 1]); ax.set_axis_off(); ax.grid(False)
    cmap = LinearSegmentedColormap.from_list("smoke", ["#3F6FA8", "#9DBDE0", "#FFFFFF"])
    seeds = np.c_[np.full(64, gx[0] + 1e-3), np.linspace(gy[0] + 0.02, gy[-1] - 0.02, 64)]
    ax.streamplot(gx, gy, U, V, start_points=seeds, integration_direction="forward",
                  broken_streamlines=False, color=speed, cmap=cmap, norm=plt.Normalize(0.75, 1.45),
                  linewidth=0.85, arrowstyle="-", density=30, maxlength=40)
    ax.fill(xr, yr, color="#0B2545", zorder=5)
    ax.plot(xr, yr, color="white", lw=1.2, zorder=6)
    ax.set_xlim(gx[0], gx[-1]); ax.set_ylim(gy[0], gy[-1]); ax.set_aspect("equal")
    f.savefig(OUT / "cover.png", dpi=300, transparent=True)
    plt.close(f)
    R["cover"] = dict(section="NACA 4412", alpha=al, cl=round(sol.cl_p, 3), panels=sol.n)


# ------------------------------------------------------------------ study 1: panel method
def study_panel():
    kt, jk = KarmanTrefftz(0.08, 0.0, 16.0), Joukowski(0.0925, 0.0)
    al = 8.0
    ns = np.array([40, 80, 160, 320, 640, 1280])
    e_kt, e_jk, dres = [], [], []
    for n in ns:
        s = panel.solve(*kt.nodes(n), al); e_kt.append(abs(s.cl_p - kt.exact(al)[3])); dres.append(abs(s.cd_p))
        s = panel.solve(*jk.nodes(n), al); e_jk.append(abs(s.cl_p - jk.exact(al)[3]))
    e_kt, e_jk = np.array(e_kt), np.array(e_jk)
    cl_ex = kt.exact(al)[3]
    xk, yk = kt.nodes(400)
    R["panel"] = dict(order_kt=round(order(e_kt, ns), 2), order_cusp=round(order(e_jk, ns), 2),
                      err320_pct=round(100 * e_kt[3] / cl_ex, 2), err1280_pct=round(100 * e_kt[-1] / cl_ex, 3),
                      cl_exact=round(cl_ex, 4), cd_res_320=float(f"{dres[3]:.1e}"),
                      thickness_pct=round(100 * (yk.max() - yk.min()), 1), te_angle=16)
    # NACA 0012 lift at 10 deg: grid-converged inviscid value
    cls = [panel.solve(*naca4("0012", n), 10.0).cl_p for n in (200, 400, 800)]
    p = math.log((cls[1] - cls[0]) / (cls[2] - cls[1])) / math.log(2)
    R["panel"].update(naca_cl10=round(cls[2] + (cls[2] - cls[1]) / (2**p - 1), 3), naca_order=round(p, 2),
                      thin_cl10=round(2 * math.pi * math.radians(10), 3), nasa_cl10=1.0909)

    f, ax = fig()                                           # (a) Cp against the exact solution
    xe, ye, cpe, _ = kt.exact(al)
    s = panel.solve(*kt.nodes(120), al)
    ax.plot(xe, cpe, color=REF, lw=1.5, label="Exact (conformal mapping)")
    dot(ax, s.xm[::2], s.cp[::2], BLUE, label="Panel method, 120 panels")
    ax.invert_yaxis(); ax.set_xlabel("x / c"); ax.set_ylabel("Cp")
    ax.set_xlim(-0.02, 1.02); ax.legend(loc="upper right")
    ax.annotate("upper surface", (0.42, -0.95), color=MUTE, fontsize=7.2)
    ax.annotate("lower surface", (0.42, 0.52), color=MUTE, fontsize=7.2)
    save(f, "panel_cp")

    f, ax = fig()                                           # (b) order of accuracy
    ax.loglog(ns, e_kt, color=BLUE); dot(ax, ns, e_kt, BLUE, label="Finite trailing-edge angle (16°)")
    ax.loglog(ns, e_jk, color=ORANGE); dot(ax, ns, e_jk, ORANGE, label="Cusped trailing edge")
    ref = e_kt[0] * 0.5 * (ns[0] / ns)
    ax.loglog(ns, ref, color=REF, lw=0.9); ax.annotate("slope 1", (ns[-1], ref[-1]), xytext=(7, -2.5), textcoords="offset points", color=MUTE, fontsize=7.2)
    ax.set_xlabel("Number of panels"); ax.set_ylabel("Error in lift coefficient")
    ax.set_xticks(ns); ax.set_xticklabels([str(n) for n in ns]); ax.minorticks_off()
    ax.set_xlim(ns[0] / 1.25, ns[-1] * 2.9); ax.set_ylim(2.5e-5, 0.3); ax.legend(loc="lower left")
    ax.annotate(f"order {R['panel']['order_kt']:.2f}", (ns[-1], e_kt[-1]), xytext=(7, -2.5), textcoords="offset points", ha="left", color=INK, fontsize=7.4)
    ax.annotate(f"order {R['panel']['order_cusp']:.2f}", (ns[-1], e_jk[-1]), xytext=(7, -2.5), textcoords="offset points", ha="left", color=INK, fontsize=7.4)
    save(f, "panel_order")


# ------------------------------------------------------------------ study 2: boundary layer and drag
def study_drag():
    s = np.linspace(0, 1, 400); one = np.ones_like(s)
    lam = ibl.march(s, one, 5e5)
    tur = ibl.march(s, one, 6e6, x_trip=0.0005)
    R["drag"] = dict(lam_plate_pct=round(100 * (lam["theta"][-1] * math.sqrt(5e5) / 0.664 - 1), 1),
                     turb_plate_pct=round(100 * (2 * tur["theta"][-1] / (0.455 / math.log10(6e6) ** 2.58) - 1), 1))
    alphas = np.arange(0, 11, 1.0)
    trip, free, xtr_u = [], [], []
    for a in alphas:
        sol = panel.solve(*naca4("0012", 300), a)
        d, fr = ibl.profile_drag(sol, 6e6, x_trip=0.05), ibl.profile_drag(sol, 6e6)
        trip.append(d["cd"]); free.append(fr["cd"]); xtr_u.append(fr["upper"]["x_tr"])
    trip, free = np.array(trip), np.array(free)
    nasa = {0: 0.00819, 10: 0.01231}
    R["drag"].update(cd0_trip=round(trip[0], 5), cd0_free=round(free[0], 5), cd10_trip=round(trip[10], 5),
                     cd0_dev_pct=round(100 * (trip[0] / nasa[0] - 1), 1), cd10_dev_pct=round(100 * (trip[10] / nasa[10] - 1), 1),
                     laminar_saving_pct=round(100 * (1 - free[0] / trip[0])), xtr0=round(xtr_u[0], 2), xtr4=round(xtr_u[4], 2))
    sens = [ibl.profile_drag(panel.solve(*naca4("0012", 300), 0.0), 6e6, 0.05, xe)["cd"] for xe in (0.95, 0.995)]
    R["drag"]["te_sens_pct"] = round(100 * (sens[1] - sens[0]) / trip[0], 1)
    hi = ibl.profile_drag(panel.solve(*naca4("0012", 300), 14.0), 6e6, 0.05)
    R["drag"]["sep14"] = None if hi["upper"]["x_sep"] is None else round(float(hi["upper"]["x_sep"]), 2)
    R["drag"]["H_te_14"] = round(float(hi["upper"]["H"][-1]), 2)

    f, ax = fig()                                           # (a) drag against angle of attack
    ax.plot(alphas, trip * 1e4, color=BLUE, label="Tripped at 5% chord")
    ax.plot(alphas, free * 1e4, color=ORANGE, label="Free transition")
    dot(ax, list(nasa), [v * 1e4 for v in nasa.values()], INK, label="NASA reference, fully turbulent RANS")
    ax.set_xlabel("Angle of attack (deg)"); ax.set_ylabel("Cd  (drag counts, ×10⁻⁴)")
    ax.set_ylim(40, 135); ax.set_xlim(-0.4, 10.4); ax.legend(loc="upper left")
    save(f, "drag_polar")

    f, ax = fig()                                           # (b) skin friction, upper surface, alpha = 0
    sol = panel.solve(*naca4("0012", 300), 0.0)
    d, fr = ibl.profile_drag(sol, 6e6, x_trip=0.05), ibl.profile_drag(sol, 6e6)
    for r, c, lab in ((d["upper"], BLUE, "Tripped at 5% chord"), (fr["upper"], ORANGE, "Free transition")):
        m = r["x"] > 0.004
        ax.plot(r["x"][m], r["cf"][m] * 1e3, color=c, label=lab)
    ax.set_ylim(0, 6.5); ax.set_xlim(0, 1.0); ax.set_xlabel("x / c"); ax.set_ylabel("Skin-friction coefficient  (×10⁻³)")
    ax.annotate("laminar run", (0.085, 1.22), color=MUTE, fontsize=7.2)
    ax.annotate(f"transition at {fr['upper']['x_tr']:.2f} c\n(Michel's criterion)", (fr["upper"]["x_tr"] + 0.035, 4.75), color=MUTE, fontsize=7.2)
    ax.legend(loc="lower right", bbox_to_anchor=(1.0, 0.02))
    save(f, "drag_cf")


# ------------------------------------------------------------------ study 3: finite wing
def at_cl(ar, chord, twist_deg=0.0, cl=0.5):
    tw = (lambda e: twist_deg * e) if twist_deg else None
    lo, hi = 0.0, 20.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        lo, hi = (lo, mid) if llt.solve(ar, chord, mid, tw)["CL"] > cl else (mid, hi)
    return llt.solve(ar, chord, mid, tw)


def study_wing():
    ell = llt.solve(8, llt.elliptic(), 5.0)
    exact = 2 * math.pi * math.radians(5) / (1 + 2 / 8)
    lam = np.linspace(0.0, 1.0, 41)
    f, ax = fig()
    cols = {6: AQUA, 8: BLUE, 10: ORANGE}
    best = {}
    for ar in (6, 8, 10):
        d = np.array([1 / llt.solve(ar, llt.tapered(l), 5.0)["e"] - 1 for l in lam]) * 100
        ax.plot(lam, d, color=cols[ar], label=f"Aspect ratio {ar}")
        i = int(d.argmin()); best[ar] = (float(lam[i]), float(d[i]), float(d[-1]))
        ax.annotate(f"AR {ar}", (1.0, d[-1]), xytext=(4, -2.5), textcoords="offset points", color=INK, fontsize=7.2, annotation_clip=False)
    dot(ax, [best[8][0]], [best[8][1]], BLUE)
    ax.annotate(f"minimum at taper {best[8][0]:.2f}", (best[8][0], best[8][1]), xytext=(0.30, 6.3), color=INK, fontsize=7.2,
                arrowprops=dict(arrowstyle="-", color=AXIS, lw=0.7, shrinkB=4))
    ax.set_xlabel("Taper ratio  (tip chord / root chord)"); ax.set_ylabel("Induced-drag penalty over elliptic (%)")
    ax.set_ylim(0, 19); ax.set_xlim(0, 1.0); ax.legend(loc="upper center")
    f.subplots_adjust(right=0.89)
    save(f, "wing_taper")

    twists = np.arange(0, -7.01, -0.25)
    es = [at_cl(8, llt.tapered(1.0), t)["e"] for t in twists]
    it = int(np.argmax(es))
    rect, tap, tw = at_cl(8, llt.tapered(1.0)), at_cl(8, llt.tapered(best[8][0])), at_cl(8, llt.tapered(1.0), twists[it])
    R["wing"] = dict(ell_err=float(f"{abs(ell['CL'] - exact):.1e}"), ell_e=round(ell["e"], 6),
                     best_taper=best[8][0], pen_best=round(best[8][1], 1), pen_rect=round(best[8][2], 1),
                     pen_rect6=round(best[6][2], 1), pen_rect10=round(best[10][2], 1),
                     twist=float(-twists[it]), e_rect=round(rect["e"], 3), e_twist=round(tw["e"], 3), e_taper=round(tap["e"], 3),
                     pen_twist=round(100 * (1 / tw["e"] - 1), 1),
                     cdi_rect=round(rect["CDi"] * 1e4, 1), cdi_twist=round(tw["CDi"] * 1e4, 1),
                     conv=float(f"{abs(llt.solve(8, llt.tapered(1.0), 5.0, n_terms=20)['e'] - llt.solve(8, llt.tapered(1.0), 5.0, n_terms=160)['e']):.0e}"))
    f, ax = fig()
    eta = rect["eta"]
    ax.plot(eta, 4 / math.pi * np.sqrt(1 - eta**2), color=REF, lw=1.2, label="Elliptic (minimum induced drag)")
    ax.plot(eta, rect["load"], color=ORANGE, label="Rectangular")
    ax.plot(eta, tw["load"], color=AQUA, label=f"Rectangular, {-twists[it]:.1f}° washout")
    ax.plot(eta, tap["load"], color=BLUE, label=f"Taper {best[8][0]:.2f}")
    ax.set_xlabel("Spanwise position  2y / b"); ax.set_ylabel("Span loading  c·cl / (c̄·CL)")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.42); ax.legend(loc="lower left")
    save(f, "wing_loading")


# ------------------------------------------------------------------ study 4: propeller
def study_prop():
    f, ax = fig()
    cols = {0.6: AQUA, 0.8: BLUE, 1.0: ORANGE}
    peak = {}
    for pr in (0.6, 0.8, 1.0):
        p = bemt.Propeller(pitch_ratio=pr)
        js = np.arange(0.10, 1.2, 0.02); eta = []
        for j in js:
            r = p.run(j)
            if r["CT"] <= 0:
                j0 = j_prev + (j - j_prev) * ct_prev / (ct_prev - r["CT"])     # thrust goes through zero here
                break
            eta.append(r["eta"]); j_prev, ct_prev = j, r["CT"]
        js = np.append(js[:len(eta)], j0); eta.append(0.0)
        ax.plot(js, eta, color=cols[pr], label=f"P/D {pr:.1f}")
        i = int(np.argmax(eta)); peak[pr] = (float(js[i]), float(eta[i]))
        ax.annotate(f"{eta[i]:.2f}", (js[i], eta[i]), xytext=(0, 4), textcoords="offset points", ha="center", color=INK, fontsize=7.2)
    ax.set_xlabel("Advance ratio  J = V / (n·D)"); ax.set_ylabel("Propulsive efficiency")
    ax.set_ylim(0, 1.0); ax.set_xlim(0.1, 1.12)
    ax.legend(loc="lower left", bbox_to_anchor=(-0.02, 1.0), ncol=3, columnspacing=1.6)
    f.subplots_adjust(top=0.905)
    save(f, "prop_eta")

    p = bemt.Propeller(pitch_ratio=0.8)
    js = [0.3, 0.4, 0.5, 0.6, 0.7]
    rs = [p.run(j) for j in js]
    f, ax = fig()
    ax.grid(axis="x", visible=False)
    b = np.zeros(len(js))
    for key, c, lab in (("useful", BLUE, "Useful thrust power"), ("induced", ORANGE, "Induced losses (slipstream, swirl, tip)"), ("profile", AQUA, "Profile drag")):
        v = np.array([r[key] for r in rs]) * 100
        ax.bar(range(len(js)), v - 1.2, bottom=b + 0.6, width=0.42, color=c, label=lab, linewidth=0)
        b += v
    for i, r in enumerate(rs):
        ax.annotate(f"{100 * r['useful']:.0f}%", (i, 100 * r["useful"] / 2), ha="center", va="center", color="white", fontsize=7.4, fontname="IBM Plex Sans SemiBold")
    ax.set_xticks(range(len(js))); ax.set_xticklabels([f"{j:.1f}" for j in js])
    ax.set_xlabel("Advance ratio  J"); ax.set_ylabel("Share of shaft power (%)")
    ax.set_ylim(0, 152); ax.set_yticks([0, 25, 50, 75, 100]); ax.legend(loc="upper left", ncol=1)
    save(f, "prop_budget")

    inv, des = p.run(0.5, tip_loss=False, drag=False), p.run(0.6)
    conv = [bemt.Propeller(pitch_ratio=0.8, n_el=n).run(0.5)["CT"] for n in (20, 40, 80)]
    R["prop"] = dict(peaks={str(k): [round(v[0], 2), round(v[1], 3)] for k, v in peak.items()},
                     inv_eta=round(inv["eta"], 3), inv_ideal=round(inv["eta_ideal"], 3),
                     ct06=round(des["CT"], 4), cp06=round(des["CP"], 4), eta06=round(des["eta"], 3), ideal06=round(des["eta_ideal"], 3),
                     useful06=round(100 * des["useful"]), induced06=round(100 * des["induced"]), profile06=round(100 * des["profile"]),
                     budget_closure=float(f"{des['closure']:.0e}"), axial06=round(100 * des["axial"], 1), swirl06=round(100 * des["swirl"], 1),
                     grid_change_pct=round(100 * abs(conv[2] - conv[1]) / conv[2], 2), blades=2)


# ------------------------------------------------------------------ study 5: shock capturing
def study_euler():
    ns = np.array([25, 50, 100, 200, 400])
    e1 = np.array([euler1d.smooth_wave(n, 1)[3] for n in ns])
    e2 = np.array([euler1d.smooth_wave(n, 2, "vanleer")[3] for n in ns])
    nsod = np.array([100, 200, 400, 800, 1600])
    s1 = np.array([euler1d.sod(n, 1)[3] for n in nsod]); s2 = np.array([euler1d.sod(n, 2, "vanleer")[3] for n in nsod])
    _, ps, us = euler1d.exact_riemann((1, 0, 1), (0.125, 0, 0.1), np.array([0.0]))
    R["euler"] = dict(order1=round(order(e1, ns), 2), order2=round(order(e2, ns), 2),
                      sod_order1=round(order(s1, nsod), 2), sod_order2=round(order(s2, nsod), 2),
                      p_star=round(float(ps), 5), u_star=round(float(us), 5),
                      err_ratio_200=round(float(s1[1] / s2[1]), 1))
    w = euler1d.sod(200, 2, "vanleer")[1]
    R["euler"]["overshoot"] = float(f"{max(w[0].max() - 1.0, 0.125 - w[0].min(), 0.0):.1e}")
    R["euler"]["monotone"] = bool((np.diff(w[0]) <= 1e-12).all())
    f, ax = fig()
    x, w1, ex, _ = euler1d.sod(200, 1); _, w2, _, _ = euler1d.sod(200, 2, "vanleer")
    xf = np.linspace(0, 1, 4001); exf = euler1d.exact_riemann((1, 0, 1), (0.125, 0, 0.1), (xf - 0.5) / 0.2)[0]
    ax.plot(xf, exf[0], color=REF, lw=1.2, label="Exact Riemann solution")
    ax.plot(x, w1[0], color=ORANGE, label="First order")
    ax.plot(x, w2[0], color=BLUE, label="Second order, van Leer limiter")
    ax.set_xlabel("x"); ax.set_ylabel("Density"); ax.set_xlim(0, 1); ax.set_ylim(0, 1.08); ax.legend(loc="lower left")
    for xa, ya, t in ((0.33, 0.80, "expansion fan"), (0.60, 0.47, "contact"), (0.80, 0.31, "shock")):
        ax.annotate(t, (xa, ya), color=MUTE, fontsize=7.2)
    save(f, "euler_sod")

    f, ax = fig()
    ax.loglog(ns, e1, color=ORANGE); dot(ax, ns, e1, ORANGE, label="First order")
    ax.loglog(ns, e2, color=BLUE); dot(ax, ns, e2, BLUE, label="Second order, van Leer limiter")
    ax.loglog(ns, e2[0] * 0.45 * (ns[0] / ns) ** 2, color=REF, lw=0.9)
    ax.annotate("slope 2", (ns[-1], e2[0] * 0.45 * (ns[0] / ns[-1]) ** 2), xytext=(7, -2.5), textcoords="offset points", color=MUTE, fontsize=7.2)
    ax.annotate(f"order {R['euler']['order1']:.2f}", (ns[-1], e1[-1]), xytext=(7, -2.5), textcoords="offset points", ha="left", color=INK, fontsize=7.4)
    ax.annotate(f"order {R['euler']['order2']:.2f}", (ns[-1], e2[-1]), xytext=(7, -2.5), textcoords="offset points", ha="left", color=INK, fontsize=7.4)
    ax.set_xticks(ns); ax.set_xticklabels([str(n) for n in ns]); ax.minorticks_off()
    ax.set_xlim(ns[0] / 1.25, ns[-1] * 2.9)
    ax.set_xlabel("Number of cells"); ax.set_ylabel("L1 error in density"); ax.legend(loc="lower left")
    save(f, "euler_order")


# ------------------------------------------------------------------ study 6: Poisson solvers
def study_poisson():
    poisson.solve_multigrid(15); poisson.solve_stationary(15, "sor"); poisson.solve_stationary(15, "jacobi")   # compile
    ns = np.array([31, 63, 127, 255, 511, 1023])
    res = {k: [] for k in ("jacobi", "gs", "sor", "cg", "mg")}
    for n in ns:
        for k in ("jacobi", "gs"):
            res[k].append(poisson.solve_stationary(n, k, max_iter=3_000_000) if n <= 255 else None)
        res["sor"].append(poisson.solve_stationary(n, "sor", max_iter=3_000_000))
        res["cg"].append(poisson.solve_cg(n))
        res["mg"].append(poisson.solve_multigrid(n))
    it = {k: np.array([r["iters"] if r else np.nan for r in v], float) for k, v in res.items()}
    tm = {k: np.array([r["time"] if r else np.nan for r in v], float) for k, v in res.items()}
    err = np.array([r["err"] for r in res["mg"]])
    slope = lambda y, x: float(np.log(y[-1] / y[0]) / np.log(x[-1] / x[0]))
    mg = res["mg"][-1]
    R["poisson"] = dict(
        s_jacobi=round(slope(it["jacobi"][:4], ns[:4]), 2), s_gs=round(slope(it["gs"][:4], ns[:4]), 2),
        s_sor=round(slope(it["sor"], ns), 2), s_cg=round(slope(it["cg"], ns), 2),
        mg_cycles_min=int(np.nanmin(it["mg"])), mg_cycles_max=int(np.nanmax(it["mg"])),
        mg_factor=round(float(np.exp(np.mean(np.log(mg["hist"][2:] / mg["hist"][1:-1])))), 3),
        disc_order=round(float(np.log2(err[-2] / err[-1])), 2),
        t_mg_1023=round(tm["mg"][-1], 2), t_sor_1023=round(tm["sor"][-1], 1), t_cg_1023=round(tm["cg"][-1], 1),
        t_jacobi_255=round(tm["jacobi"][3], 1), t_mg_255=round(tm["mg"][3], 3),
        s_t_mg=round(slope(tm["mg"][2:], ns[2:] ** 2), 2), s_t_sor=round(slope(tm["sor"][2:], ns[2:] ** 2), 2),
        unknowns_1023=int(1023 ** 2), it_jacobi_255=int(it["jacobi"][3]), it_mg_255=int(it["mg"][3]))

    names = {"jacobi": ("Jacobi", REF), "gs": ("Gauss–Seidel", AQUA), "sor": ("SOR, optimal ω", ORANGE), "cg": ("Conjugate gradients", BLUE), "mg": ("Multigrid V-cycles", INK)}
    f, ax = fig()
    for k, (lab, c) in names.items():
        m = ~np.isnan(it[k]); ax.loglog(ns[m], it[k][m], color=c); dot(ax, ns[m], it[k][m], c, label=lab)
    ax.set_xlabel("Grid points per side"); ax.set_ylabel("Iterations to reduce the residual by 10⁸")
    ax.set_xticks(ns); ax.set_xticklabels([str(n) for n in ns]); ax.minorticks_off()
    ax.set_xlim(ns[0] / 1.3, ns[-1] * 2.6); ax.set_ylim(3, 6e5)
    ax.legend(loc="upper left", fontsize=6.9)
    for k, txt in (("jacobi", "∝ n²"), ("sor", "∝ n"), ("mg", "constant")):
        m = ~np.isnan(it[k]); ax.annotate(txt, (ns[m][-1], it[k][m][-1]), xytext=(6, -2.5), textcoords="offset points", color=INK, fontsize=7.2)
    save(f, "poisson_iters")

    f, ax = fig()
    N = ns.astype(float) ** 2
    for k, (lab, c) in names.items():
        m = ~np.isnan(tm[k]); ax.loglog(N[m], tm[k][m], color=c); dot(ax, N[m], tm[k][m], c, label=lab)
    ref = tm["mg"][2] * 0.5 * (N / N[2])
    ax.loglog(N, ref, color=REF, lw=0.9); ax.annotate("slope 1", (N[-1], ref[-1]), xytext=(6, -2.5), textcoords="offset points", color=MUTE, fontsize=7.2)
    ax.set_xlabel("Number of unknowns"); ax.set_ylabel("Time to solution (s)")
    ax.set_xlim(N[0] / 1.5, N[-1] * 3); ax.legend(loc="lower right", fontsize=6.9)
    save(f, "poisson_time")


# ------------------------------------------------------------------ study 7: roofline
def study_roofline():
    rf = {}
    for th in (1, 2):
        rf[th] = dict(peak=roofline.peak_flops(threads=th), bw=roofline.stream_triad(threads=th), st=roofline.stencil_rates(threads=th))
    ai = rf[1]["st"]["intensity"]; tf = roofline.numpy_traffic_factor()
    R["roofline"] = dict(peak1=round(rf[1]["peak"], 1), peak2=round(rf[2]["peak"], 1), bw1=round(rf[1]["bw"], 1), bw2=round(rf[2]["bw"], 1),
                         ridge1=round(rf[1]["peak"] / rf[1]["bw"], 1), ai=ai, traffic_factor=tf,
                         fused_pct1=round(100 * rf[1]["st"]["fused"]["gbs"] / rf[1]["bw"]), fused_pct2=round(100 * rf[2]["st"]["fused"]["gbs"] / rf[2]["bw"]),
                         numpy_slow=round(rf[1]["st"]["numpy"]["time"] / rf[1]["st"]["fused"]["time"], 1),
                         blocked_vs_fused=round(100 * (rf[1]["st"]["blocked"]["time"] / rf[1]["st"]["fused"]["time"] - 1)),
                         fused_gflops1=round(rf[1]["st"]["fused"]["gflops"], 2), bound_gflops1=round(ai * rf[1]["bw"], 2),
                         speedup2=round(rf[1]["st"]["fused"]["time"] / rf[2]["st"]["fused"]["time"], 2),
                         headroom=round(rf[1]["peak"] / (ai * rf[1]["bw"])), cores=2)
    f, ax = fig()
    x = np.logspace(-2, 2, 200)
    for th, c, lab in ((1, BLUE, "1 core"), (2, ORANGE, "2 cores")):
        ax.loglog(x, np.minimum(rf[th]["peak"], rf[th]["bw"] * x), color=c, lw=1.4, label=f"Roofline, {lab}")
    for th, c in ((1, BLUE), (2, ORANGE)):
        st = rf[th]["st"]
        dot(ax, [ai, ai], [st["fused"]["gflops"], st["blocked"]["gflops"]], c)
        dot(ax, [ai / tf], [st["numpy"]["gflops"]], c)
    ax.annotate("fused kernel", (ai, rf[1]["st"]["fused"]["gflops"]), xytext=(8, -10), textcoords="offset points", color=INK, fontsize=7.2)
    ax.annotate("NumPy slicing,\nat its real traffic", (ai / tf, rf[1]["st"]["numpy"]["gflops"]), xytext=(8, -14), textcoords="offset points", color=INK, fontsize=7.2)
    ax.annotate("ridge point", (rf[1]["peak"] / rf[1]["bw"], rf[1]["peak"]), xytext=(4, -11), textcoords="offset points", color=MUTE, fontsize=7.2)
    ax.axvline(ai, color=GRID, lw=0.8, zorder=0)
    ax.set_xlabel("Arithmetic intensity (FLOP per byte)"); ax.set_ylabel("GFLOP/s")
    ax.set_xlim(0.01, 100); ax.set_ylim(0.1, 300); ax.legend(loc="upper left")
    save(f, "roofline")

    f, ax = fig(); ax.grid(axis="x", visible=False)
    labels = ["NumPy slicing", "Fused (Numba)", "Fused, blocked"]
    xs = np.arange(3)
    for k, (th, c, lab) in enumerate(((1, BLUE, "1 core"), (2, ORANGE, "2 cores"))):
        v = [rf[th]["st"][key]["gbs"] for key in ("numpy", "fused", "blocked")]
        ax.bar(xs + (k - 0.5) * 0.36, v, width=0.33, color=c, label=lab, linewidth=0)
        ax.axhline(rf[th]["bw"], color=c, lw=0.9, ls=(0, (3, 2)))
        ax.annotate(f"STREAM, {lab}: {rf[th]['bw']:.1f} GB/s", (2.55, rf[th]["bw"]), xytext=(0, 3), textcoords="offset points", ha="right", color=c, fontsize=7)
    ax.set_xticks(xs); ax.set_xticklabels(labels); ax.set_ylabel("Useful memory traffic (GB/s)")
    ax.set_xlim(-0.6, 2.6); ax.set_ylim(0, rf[2]["bw"] * 1.25); ax.legend(loc="upper left")
    save(f, "roofline_bars")


# ------------------------------------------------------------------ study 8: domain decomposition
def study_decomp():
    pp = decomp.pingpong(); rate = decomp.compute_rate()
    ns = np.array([128, 256, 512, 1024, 2048, 4096])
    meas, cpr = [], []
    for n in ns:
        r1, r2 = decomp.best_of(n, 1, steps=100, repeats=5), decomp.best_of(n, 2, steps=100, repeats=5)
        meas.append(r1["wall"] / (2 * r2["wall"])); cpr.append(n * n / 2)
    meas, cpr = np.array(meas), np.array(cpr, float)
    c = np.logspace(3, 7.2, 200)
    mpi = dict(latency=1.5e-6, bandwidth=10e9)
    e2 = decomp.model_efficiency(c, 2, rate, pp["latency"], pp["bandwidth"])
    e64 = decomp.model_efficiency(c, 64, rate, pp["latency"], pp["bandwidth"])
    e64m = decomp.model_efficiency(c, 64, rate, **mpi)
    cross = lambda e: float(c[np.argmax(e >= 0.9)])
    R["decomp"] = dict(latency_us=round(pp["latency"] * 1e6, 1), bw_gbs=round(pp["bandwidth"] / 1e9, 2), rate_m=round(rate / 1e6),
                       eff_min=round(float(meas[0]), 2), eff_max=round(float(meas[-1]), 2), cpr_min=int(cpr[0]), cpr_max=int(cpr[-1]),
                       model_dev=round(float(np.abs(meas - decomp.model_efficiency(cpr, 2, rate, pp["latency"], pp["bandwidth"])).max()), 2),
                       cross_here=int(round(cross(e64), -3)), cross_mpi=int(round(cross(e64m), -2)),
                       halo_bytes_2048=int(8 * 2048), ratio_latency=int(round(pp["latency"] / mpi["latency"])))
    f, ax = fig()
    ax.loglog(pp["sizes"], pp["times"] * 1e6, color=BLUE); dot(ax, pp["sizes"], pp["times"] * 1e6, BLUE, label="Measured, one way")
    ax.axhline(pp["latency"] * 1e6, color=REF, lw=0.9, ls=(0, (3, 2)))
    ax.annotate(f"latency {pp['latency']*1e6:.0f} µs", (pp["sizes"][0], pp["latency"] * 1e6), xytext=(0, 4), textcoords="offset points", color=MUTE, fontsize=7.2)
    big = pp["sizes"] >= 2e5
    ax.loglog(pp["sizes"][big], pp["sizes"][big] / pp["bandwidth"] * 1e6, color=REF, lw=0.9)
    ax.annotate(f"{pp['bandwidth']/1e9:.1f} GB/s", (pp["sizes"][-1], pp["sizes"][-1] / pp["bandwidth"] * 1e6), xytext=(-4, -11), textcoords="offset points", ha="right", color=MUTE, fontsize=7.2)
    ax.set_xlabel("Message size (bytes)"); ax.set_ylabel("Time per message (µs)")
    ax.set_xticks([1e1, 1e3, 1e5, 1e7]); ax.minorticks_off(); ax.legend(loc="upper left")
    save(f, "decomp_pingpong")

    f, ax = fig()
    ax.semilogx(c, e2, color=BLUE, label="2 ranks, model")
    dot(ax, cpr, meas, BLUE, label="2 ranks, measured")
    ax.semilogx(c, e64, color=ORANGE, label="64 ranks, model, this channel")
    ax.semilogx(c, e64m, color=ORANGE, ls=(0, (3, 2)), label="64 ranks, model, 1.5 µs / 10 GB/s")
    ax.axhline(0.9, color=GRID, lw=0.8, zorder=0)
    ax.set_xlabel("Cells per rank"); ax.set_ylabel("Parallel efficiency")
    ax.set_ylim(0, 1.05); ax.set_xlim(1e3, 1.6e7)
    ax.legend(loc="lower left", bbox_to_anchor=(-0.02, 1.0), ncol=2, fontsize=6.6, columnspacing=1.0)
    f.subplots_adjust(top=0.86)
    save(f, "decomp_eff")


if __name__ == "__main__":
    import sys
    steps = (cover, study_panel, study_drag, study_wing, study_prop, study_euler, study_poisson, study_roofline, study_decomp)
    chosen = [s for s in steps if not sys.argv[1:] or s.__name__ in sys.argv[1:]]
    if sys.argv[1:] and (OUT / "results.json").exists():
        R.update(json.loads((OUT / "results.json").read_text()))
    for step in chosen:
        step(); print("done", step.__name__, flush=True)
    (OUT / "results.json").write_text(json.dumps(R, indent=1))
    print(json.dumps(R, indent=1))
