"""Integral boundary-layer method, one-way coupled to an inviscid edge velocity.

Laminar: Thwaites. Transition: Michel's criterion, laminar separation, or a fixed trip.
Turbulent: Head's entrainment method with the Ludwieg-Tillmann skin-friction law.
Profile drag: Squire-Young.
"""
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.integrate import solve_ivp, cumulative_trapezoid


def _thwaites_shape(lam):
    lam = np.clip(lam, -0.1, 0.1)
    if lam >= 0:
        return 0.22 + 1.57 * lam - 1.8 * lam**2, 2.61 - 3.75 * lam + 5.24 * lam**2
    return 0.22 + 1.402 * lam + 0.018 * lam / (lam + 0.107), 2.088 + 0.0731 / (lam + 0.14)


def _h_from_h1(h1):
    h1 = max(h1, 3.32)
    return 1.1 + 0.86 * (h1 - 3.3) ** -0.777 if h1 >= 5.3 else 0.6778 + 1.1536 * (h1 - 3.3) ** -0.326


def _h1_from_h(h):
    return 3.3 + 0.8234 * (h - 1.1) ** -1.287 if h <= 1.6 else 3.3 + 1.5501 * (h - 0.6778) ** -3.064


def march(s, ue, re, x=None, x_trip=None, n_out=400):
    """March one surface from the stagnation point.

    s: arc length from stagnation (chord = 1), ue: edge velocity / U_inf, re: chord Reynolds number.
    x: chordwise coordinate matching s (for the trip location and reporting).
    Returns a dict of distributions and the transition / separation locations.
    """
    s, ue = np.asarray(s, float), np.asarray(ue, float)
    x = s if x is None else np.asarray(x, float)
    nu = 1.0 / re
    f_ue, f_x = PchipInterpolator(s, ue), PchipInterpolator(s, x)
    df_ue = f_ue.derivative()
    so = np.linspace(s[0], s[-1], n_out) if s[0] > 0 else np.concatenate(
        [[0.0], np.geomspace(1e-5, s[-1], n_out - 1)])
    uo, duo, xo = f_ue(so), df_ue(so), f_x(so)

    # ---- laminar: Thwaites ----
    integ = cumulative_trapezoid(uo**5, so, initial=0.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        th2 = 0.45 * nu * integ / uo**6
    th2[0] = 0.075 * nu / max(duo[0], 1e-9) if uo[0] < 1e-6 else th2[0]   # stagnation-point limit
    theta = np.sqrt(np.maximum(th2, 0.0))
    lam = th2 * duo / nu
    H = np.empty_like(so); cf = np.empty_like(so)
    i_tr, why = len(so) - 1, "none"
    for i in range(len(so)):
        l, H[i] = _thwaites_shape(lam[i])
        cf[i] = 2 * nu * l / max(uo[i] * theta[i], 1e-30)
        if i == 0:
            continue
        re_x, re_th = uo[i] * so[i] / nu, uo[i] * theta[i] / nu
        if x_trip is not None and xo[i] >= x_trip:
            i_tr, why = i, "trip"; break
        if lam[i] <= -0.09:
            i_tr, why = i, "laminar separation"; break
        if re_th > 1.174 * (1 + 22400.0 / re_x) * re_x**0.46:
            i_tr, why = i, "Michel"; break

    # ---- turbulent: Head ----
    sep = None
    if i_tr < len(so) - 1:
        h0 = 1.4
        y0 = [theta[i_tr], uo[i_tr] * theta[i_tr] * _h1_from_h(h0)]

        def rhs(sv, yv):
            th, m = yv
            u, du = float(f_ue(sv)), float(df_ue(sv))
            h = _h_from_h1(m / (u * th))
            cfl = 0.246 * 10 ** (-0.678 * h) * (u * th / nu) ** -0.268
            h1 = max(m / (u * th), 3.32)
            return [0.5 * cfl - (h + 2) * th / u * du, u * 0.0306 * (h1 - 3.0) ** -0.6169]

        sol = solve_ivp(rhs, [so[i_tr], so[-1]], y0, t_eval=so[i_tr:], rtol=1e-8, atol=1e-12,
                        method="LSODA")
        tht, m = sol.y
        for k, i in enumerate(range(i_tr, len(so))):
            theta[i] = tht[k]
            H[i] = _h_from_h1(m[k] / (uo[i] * tht[k]))
            cf[i] = 0.246 * 10 ** (-0.678 * H[i]) * (uo[i] * tht[k] / nu) ** -0.268
            if sep is None and H[i] >= 2.4:
                sep = xo[i]
    return dict(s=so, x=xo, ue=uo, theta=theta, H=H, cf=cf, x_tr=xo[i_tr], why=why, x_sep=sep)


def surfaces(sol):
    """Split a panel solution at the stagnation point into upper and lower surfaces."""
    vt = sol.vt
    i0 = int(np.where(np.sign(vt[:-1]) != np.sign(vt[1:]))[0][0])        # sign change of Vt
    f = vt[i0] / (vt[i0] - vt[i0 + 1])                                    # linear zero crossing
    sm = np.concatenate([[0.0], np.cumsum(0.5 * (sol.length[:-1] + sol.length[1:]))])
    s_stag = sm[i0] + f * (sm[i0 + 1] - sm[i0])
    x0 = sol.x.min()
    lower = dict(s=(s_stag - sm[: i0 + 1])[::-1], ue=np.abs(vt[: i0 + 1])[::-1],
                 x=(sol.xm[: i0 + 1][::-1] - x0) / sol.chord)
    upper = dict(s=sm[i0 + 1:] - s_stag, ue=np.abs(vt[i0 + 1:]), x=(sol.xm[i0 + 1:] - x0) / sol.chord)
    for d in (lower, upper):                                              # prepend the stagnation point
        d["s"] = np.concatenate([[0.0], d["s"]]); d["ue"] = np.concatenate([[0.0], d["ue"]])
        d["x"] = np.concatenate([[d["x"][0]], d["x"]])
    return upper, lower


def profile_drag(sol, re, x_trip=None, x_eval=0.98):
    """Squire-Young profile drag from both surfaces, evaluated at x/c = x_eval."""
    out, cd = {}, 0.0
    for name, srf in zip(("upper", "lower"), surfaces(sol)):
        keep = srf["x"] <= x_eval + 1e-9
        keep[0] = True
        r = march(srf["s"][keep], srf["ue"][keep], re, srf["x"][keep], x_trip)
        H_te = min(r["H"][-1], 2.4)
        cd_s = 2 * r["theta"][-1] * r["ue"][-1] ** ((H_te + 5) / 2)
        r["cd"] = cd_s; out[name] = r; cd += cd_s
    out["cd"] = cd
    return out
